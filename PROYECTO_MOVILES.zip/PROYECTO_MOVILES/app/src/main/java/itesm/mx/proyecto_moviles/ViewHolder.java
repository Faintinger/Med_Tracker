package itesm.mx.proyecto_moviles;

import android.widget.TextView;

/**
 * Created by achs on 24/10/16.
 */
public class ViewHolder {
    public TextView textView;
}
